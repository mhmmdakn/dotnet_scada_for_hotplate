﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hot_Plate_Lib
{
    public class Recete
    {
        public UInt16 [] AT_SV { get; set; }
        public UInt16[] UT_SV { get; set; }
        public bool[] AT_RUN_STOP { get; set; }
        public bool[]UT_RUN_STOP { get; set; }

        public int Basma_Suresi { get; set; }

    }
}
