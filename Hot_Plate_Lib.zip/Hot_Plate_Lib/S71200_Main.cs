﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;
using Sharp7;
namespace Hot_Plate_Lib
{

    
    public class S71200_Main : S71200
    {
       

        public event EventHandler AlarmStateChanged;
        

        public byte[] TM2_buff = new byte[2048];
        public byte[] TM2_Set_buff = new byte[256];

        public byte[] JD640_buff = new byte[512];
        public byte[] JD640_Set_buff = new byte[128];

        public byte[] Alarm_buff = new byte[256];
        
        public List<Alarm> Alarms { get; set; }
        public int AlarmDbNum { get; set; }

        public Dictionary<int, bool> currentAlarm_State = new Dictionary<int, bool>();

        public List<AlarmHistory> historyAlarms = new List<AlarmHistory>();

        private bool alarm_state;

        public bool AlarmState
        {
            get { return alarm_state; }
            set 
            {
                if (alarm_state != value)
                {
                    alarm_state = value;
                    if (AlarmStateChanged != null)
                        AlarmStateChanged.Invoke(this, new EventArgs());
                }
                    

                

            }
        }

        public bool JD640_Read { get; set; }
        public bool TM2_Read { get; set; }
        public bool Alarm_Read { get; set; }

        public S71200_Main(string ip_address,Dispatcher dispatcher,  StationName plcStationName, Dictionary<string, string> tags) : base(ip_address,dispatcher, plcStationName, tags) 
        {
        
        
        }




        public override bool Check()
        {


            
            if (!Busy)
            {
                //Busy = true;

                if (Alarm_Read)
                {
                    bool alarm_Durum = false;
                    if (DBRead(AlarmDbNum, 0, 3, ref Alarm_buff, Sharp7.S7Consts.S7WLByte))
                        for (int i = 0; i < Alarms.Count; i++)
                        {

                            bool alarm_state = S7.GetBitAt(Alarm_buff, i / 8, i % 8);
                            if (currentAlarm_State.Count != Alarms.Count)
                                currentAlarm_State.Add(i, alarm_state);
                            else
                            {
                                if (currentAlarm_State[i] != alarm_state)
                                {
                                    historyAlarms.Add(new AlarmHistory(i, DateTime.Now));
                                    if (historyAlarms.Count > 50)
                                    {
                                        historyAlarms.RemoveRange(1, 10);

                                    }
                                }

                                currentAlarm_State[i] = alarm_state;
                            }


                            alarm_Durum |= alarm_state;


                        }
                    AlarmState = alarm_Durum;

                }
                    
                

                if (TM2_Read)
                DBRead(6, 0, (int)DataBlockSize.TM2, ref TM2_buff, Sharp7.S7Consts.S7WLByte);

                if(JD640_Read)
                DBRead(23, 0, (int)DataBlockSize.JD640, ref JD640_buff, Sharp7.S7Consts.S7WLByte);



                if (userControls != null)
                {
                    //byte[][] multi_buff = new byte[256][];
                    //for (int j = 0; j < userControls.Count; j++)
                    //{
                    //    multi_buff[j] = new byte[4];
                    //}



                    //// Multi Reader Instance
                    //S7MultiVar Reader = new S7MultiVar(s7);

                    //int i = 0;

                    //foreach (PLC_BaseUserControl item in userControls)
                    //{
                    //    int area = 0, dbnum = 0, start_address = 0, bit_address = 0, word_len = 0;
                    //    string address = item.PLCReadAdress;
                    //    Tool.AddressCheck(ref address, Tags);

                    //    Tool.SplitAddress(address, ref area, ref dbnum, ref start_address, ref bit_address, ref word_len);

                    //    Reader.Add(area, word_len, dbnum, start_address, 8, ref multi_buff[i]);

                    //    i++;
                    //}
                    //int Result = Reader.Read();




                    foreach (PLC_BaseUserControl item in userControls)
                    {

                        object value = Read(item.PLCReadAdress);
                        Dispatcher.Invoke(() =>
                        {
                            item.Value = value;

                        });
                    }
                }


                // Busy = false;



            }
            //else
            //    Busy = false;




            


            return true;
        }
    }
    public enum DataBlockNum
    {
        TM2 = 6,
        TM2_Set = 11,
        JD640 = 23,
        JD640_Set = 24
    }
    public enum DataBlockSize
    {
        TM2 = 1856,
        TM2_Set = 192,
        JD640 = 312,
        JD640_Set = 160
    }

    public enum DataBlockStartIndex
    {
        Read_Input_Alt_Tabla = 0,
        Coil_Status_Alt_Tabla = 1792,
        Alt_Tabla_Set = 0,

        Read_Input_Ust_Tabla = 896,
        Coil_Status_Ust_Tabla = 1824,
        Ust_Tabla_Set = 96,

        Servo_Read=0,
        Servo_Set_Read=104
    }


    #region JD640
    public enum JD640_Byte_Len
    {
        Servo_Read = 26,
        Servo_Set_Read = 52,
        Status_Word=2,
        Error_State = 2,
        Din_Status = 2,
        Dout_Status=2,
    }
    public enum Servo_Read
    {
        I_q_Int=0,
        Pos_Error_DInt=2,
        Pos_Actual_DInt=6,
        Speed_RPM_Int=10,
        Status_Word=12,
        Error_State_1 = 14,
        Error_State_2= 16,
        Din_Status = 18,
        Dout_Status = 20,
        Error_State_1_UInt=22,
        Error_State_2_UInt = 24,
    }

    public enum Servo_Set_Read
    {
        Din_Pos0_DInt = 0,
        Din_Pos1_DInt = 4,
        Din_Pos2_DInt = 8,
        Din_Pos3_DInt = 12,
        Din_Speed0_DInt = 16,
        Din_Speed1_DInt = 20,
        Din_Speed2_DInt = 24,
        Din_Speed3_DInt = 28,
        CMD_q_Max_UInt = 32,
        Home_Offset_DInt = 34,
        Profile_Acc_UDInt = 38,
        Profile_Dec_UDInt = 42,
        Home_Speed_UDInt = 46,
        Home_Method_Byte = 50,
        Home_OFF_M_Byte = 51,
    }

    public enum Din_Status
    {
        Enable,
        Reset_Errors,
        Operation_Mode,
        Din_Pos_Index0,
        Din_Pos_Index1,
        Active_Command,
        Start_Homing,
        Homing_Signal
    }

    public enum Dout_Status
    {
        Ready,
        reserve1,
        Drive_Enabled,
        Pos_Reached,
        reserve2,
        Motor_Brake,
        Error,
        NC
    }


    public class JD640_Const
    {
        public const float I_q = 45.4f;
        public const float Pos_Actual = 13107;
        public const float Pos_Error = 13107;
        public const float Speed_RPM = 17895.424f;


    }
    #endregion


    #region TM2
    public enum TM2_Byte_Len
    {
        Read_Input_Byte_Len = 56,
        Coil_Status_Byte_Len = 2,
        IN_OUT_Byte_Len = 2,
        TM2_Set_Byte_Len = 6

    }
    public enum TM2_Set_UINT
    {
        CH1_SV = 0,
        CH2_SV = 2,
        TM2_SET_BIT = 4
    }
    public enum TM2_Set_Bit
    {
        CH1_STOP,
        CH2_STOP,
        CH1_AUTO_TUN,
        CH2_AUTO_TUN
    }

    public enum Read_Input_UINT
    {
        CH1_Present_Value = 0,
        CH1_Set_Value = 6,
        CH2_Present_Value = 12,
        CH2_Set_Value = 18,
        Unit_Adress = 50,
        CT1_Heater_Current = 52,
        CT2_Heater_Current = 54
    }
    public enum Read_Input_Byte
    {
        IN_OUT = 49

    }


    public enum Coil_Status
    {
        CH1_RUN_STOP,
        CH1_Auto_Tuning,
        CH2_RUN_STOP,
        CH2_Auto_Tuning,
        Coil_Status_Size,


    }
    public enum IN_OUT
    {
        CH1_Lamp,
        CH2_Lamp,
        nc,
        nc_1,
        AL1_Lamp,
        AL2_Lamp,
        AL3_Lamp,
        AL4_Lamp,
        DI_1_IN,
        DI_2_IN,
        IN_OUT_Size,
    }
    #endregion
}
