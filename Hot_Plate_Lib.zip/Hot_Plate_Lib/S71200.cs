﻿using Sharp7;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace Hot_Plate_Lib
{
    public class S71200:IPLC
    {
        public bool Connected { get; set; }
        public event EventHandler Connecting_Fail;
        public event EventHandler Uptdated;
        public event EventHandler Writed;
        public List<PLC_BaseUserControl> userControls = new List<PLC_BaseUserControl>();
        public byte[] writeBuff = new byte[8];
        public byte[] readBuff = new byte[8];
        
        public bool Trying { get; set; }

        public bool Busy { get; set; }

        public Dictionary<string,string> Tags { get; set; }

        public StationName PLCStationName { get; set; }

        public S7Client s7;
        DispatcherTimer timer_connect;
        DispatcherTimer timer_Task;
        Task[] task = new Task[1];        
        int connection_try_count = 0;
        string ip_address;
        public Dispatcher Dispatcher { get; set; }

        public S71200(string ip,Dispatcher dispatcher, StationName plcStationName, Dictionary<string, string> tags)
        {
            ip_address = ip;
            PLCStationName = plcStationName;
            Dispatcher = dispatcher;
            Tags = tags;
            init();

        }


        public void init()
        {
            
            s7 = new S7Client();
            timer_connect = new DispatcherTimer();
            timer_connect.Interval = TimeSpan.FromMilliseconds(5000);
            timer_connect.IsEnabled = true;
            timer_connect.Tick += Timer_Tick;

            timer_Task = new DispatcherTimer();
            timer_Task.Interval = TimeSpan.FromMilliseconds(200);
            timer_Task.IsEnabled = true;
            timer_Task.Tick += Timer_Task_Tick;

            s7.ConnectTo(ip_address, 0, 0);
            //task[0] = new Task(() =>
            //{

            //    if (Connected)
            //    {
            //        if (Check())
            //        {
            //            if (Uptdated != null)
            //                Uptdated.Invoke(this, new EventArgs());
            //        }

            //    }
            //    Thread.Sleep(2000);
            //});
            //task[0].Start();
        }

        private async void Timer_Task_Tick(object sender, EventArgs e)
        {
            //timer_Task.Stop();

            //if (task[0].IsCompleted)
            //{
            //    task[0].Start();
            //}

            //timer_Task.Start();

            timer_Task.Stop();
            if (task[0] != null)
                await Task.WhenAll(task);
            task[0] = Task.Run(() =>
            {

                if (Connected)
                {
                    if (Check())
                    {
                        if (Uptdated != null)
                            Uptdated.Invoke(this, new EventArgs());
                    }

                }
            });

            timer_Task.Start();
        }
        public virtual bool Check()
        {
            bool result = true;

            if (!Busy)
            {

                if (userControls != null) 
                {


                    foreach (PLC_BaseUserControl item in userControls)
                    {
                        object value= Read(item.PLCReadAdress);
                        
                        Dispatcher.Invoke(() =>                         
                        {
                            item.Value = value;
                        });

                        
                    }
                }
                    
                

                
            }
            //else
            //    Busy = false;





            return result;
        }


        public async void DBWrite(int DBNum, int start_index, int Size, byte[] Buffer)
        {

            if (task[0] != null)
                await Task.WhenAll(task);
            task[0] = Task.Run(() =>
            {
                if (Connected)
                {
                    if (!Busy)
                    {
                        Busy = true;
                        int result = s7.DBWrite(DBNum, start_index, Size, Buffer);
                        Busy = false;


                        if (result == 0)
                            if (Writed != null)
                                Writed.Invoke(this, new EventArgs());
                    }

                }
            });


        }

        public async void Write_Async(string address, object value)
        {


            int area = 0, dbnum = 0, start_address = 0, bit_address = 0, word_len = 0;

            Array.Clear(writeBuff, 0, writeBuff.Length);

            Tool.AddressCheck(ref address, Tags);

            Tool.SplitAddress(address, ref area, ref dbnum, ref start_address, ref bit_address, ref word_len);

            Tool.ObjectToByte(ref writeBuff,  word_len, value, 0, bit_address);


            if (task[0] != null)
                await Task.WhenAll(task);
            task[0] = Task.Run(() =>
            {
                if (Connected)
                {
                    if (!Busy)
                    {
                        Busy = true;
                        int result = s7.WriteArea(area, dbnum, start_address, 1, word_len, writeBuff);
                        
                        Busy = false;
                        if (result == 0)
                            if (Writed != null)
                                Writed.Invoke(this, new EventArgs());
                    }



                }
            });

        }

        public async void Read_Async(string address,Dispatcher dispatcher, PLC_BaseUserControl userControl)
        {
            object value = 0;
            int area = 0, dbnum = 0, start_address = 0, bit_address = 0, word_len = 0;

            Array.Clear(readBuff, 0, readBuff.Length);

            Tool.AddressCheck(ref address, Tags);

            Tool.SplitAddress(address, ref area, ref dbnum, ref start_address, ref bit_address, ref word_len);

            if (task[0] != null)
                await Task.WhenAll(task);
            task[0] = Task.Run(() =>
            {
                if (Connected)
                {
                    if (!Busy)
                    {
                        Busy = true;
                        int result = s7.ReadArea(area, dbnum, start_address, 1, word_len, readBuff);
                        Busy = false;
                        Tool.ByteToObject(readBuff, word_len, ref value, 0, bit_address);
                        dispatcher.Invoke(() => { userControl.Value = value; });
                
                    }



                }
            });

            
        }


        public void Write(string address, object value)
        {


            int area = 0, dbnum = 0, start_address = 0, bit_address = 0, word_len = 0;

            Array.Clear(writeBuff, 0, writeBuff.Length);

            Tool.AddressCheck(ref address, Tags);

            Tool.SplitAddress(address, ref area, ref dbnum, ref start_address, ref bit_address, ref word_len);

            Tool.ObjectToByte(ref writeBuff, word_len, value, 0, bit_address);
            if (!Busy)
            {
                Busy = true;
                int result = s7.WriteArea(area, dbnum, start_address, 1, word_len, writeBuff);
                Busy = false;
            }



        }
        public object Read(string _address)
        {
            object value = 0;
            int area = 0, dbnum = 0, start_address = 0, bit_address = 0, word_len = 0;
            string address = _address;
            Array.Clear(readBuff, 0, readBuff.Length);

            Tool.AddressCheck(ref address, Tags);

            Tool.SplitAddress(address, ref area, ref dbnum, ref start_address, ref bit_address, ref word_len);

            if (!Busy)
            {
                Busy = true;
                int result = s7.ReadArea(area, dbnum, start_address, 1, word_len, readBuff);
                Tool.ByteToObject(readBuff, word_len,ref value, 0, bit_address);
                
                Busy = false;
            }

            return value;
        }

        //public bool DBRead(int DBNumber,int start,int size,ref byte[] buffer,int WordLen)
        //{
        //    int last_lenght = size;
        //    int offset = 0;
        //    int result = 0;
        //byte[] readDBBuff = new byte[512];
        //    do
        //    {

        //        if (last_lenght > 512)
        //        {

        //            result = s7.ReadArea(S7Consts.S7AreaDB, DBNumber, offset, 512, WordLen, readDBBuff);
        //            Array.Copy(readDBBuff, 0, buffer, offset, 512);
        //            offset += 512;
        //        }
        //        else
        //        {
        //            result = s7.ReadArea(S7Consts.S7AreaDB, DBNumber, offset, last_lenght, WordLen, buffer);
        //            Array.Copy(readDBBuff, 0, buffer, offset, last_lenght);

        //            offset = size;

        //        }

        //        last_lenght = size - offset;

        //        if (result != 0)
        //            return false;
        //    }
        //    while (last_lenght > 0);



        //    return true;
        //}
        public bool DBRead(int DBNumber, int start, int size, ref byte[] buffer, int WordLen)
        {
            int result = -1;
            if (!Busy)
            {
                Busy = true;
                result = s7.ReadArea(S7Consts.S7AreaDB, DBNumber, start, size, WordLen, buffer);
                Busy = false;
            }

            if(result!=0)
                return false;

            return true;
        }



        private void Timer_Tick(object sender, EventArgs e)
        {
            if (s7.Connected == false)
            {
                if (connection_try_count < 10)
                {
                    Trying = false;
                    int result = s7.ConnectTo(ip_address, 0, 0);
                    if (result == 0)
                        connection_try_count = 0;
                    else
                        connection_try_count++;
                }
                else if (Trying == true)
                {
                    connection_try_count = 0;
                }
                else
                {
                    if (Connecting_Fail != null)
                        Connecting_Fail.Invoke(this, new EventArgs());
                }

                Connected = false;
            }
            else
                Connected = true;
        }


        public async void UpdateUserControlList(List<PLC_BaseUserControl> myBaseUserControls)
        {
            if (task[0] != null)
                await Task.WhenAll(task);
            userControls.Clear();

            foreach (PLC_BaseUserControl item in myBaseUserControls)
            {
                if (item.PLCStationName == PLCStationName)
                {
                    userControls.Add(item);
                }
            }

        }

        void DenemeWrite()
        {
            //byte[] a = new byte[5];
            //s7.ABWrite(0)
        }


    }
}

