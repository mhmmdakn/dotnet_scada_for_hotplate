﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;

namespace Hot_Plate_Lib
{
    public class Alarm
    {

        public string Name { get; set; }
        public Color Color { get; set; }        
        public string Description { get; set; }
        public bool Go { get; set; }

        public Alarm(string name,Color color,string description,bool go)
        {
            Name = name;
            Color = color;
            
            Description = description;
            Go = go;
        }

    }
    public class AlarmHistory
    {

        public int Id { get; set; }
        public DateTime Date { get; set; }

        public AlarmHistory(int id,DateTime date)
        {
            Id = id;
            Date = date;
        }

    }
}
