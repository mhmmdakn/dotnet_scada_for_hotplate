﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EasyModbus;
namespace Hot_Plate_Lib
{
    public class Modbus
    {
        ModbusClient client = new ModbusClient("COM6");
    }
}
