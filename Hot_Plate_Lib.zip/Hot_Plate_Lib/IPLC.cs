﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace Hot_Plate_Lib
{
    public interface IPLC
    {
        Dictionary<string, string> Tags { get; set; }

        void Write_Async(string address, object value);
        object Read(string address);
        void Read_Async(string address, Dispatcher dispatcher, PLC_BaseUserControl userControl);
        void Write(string address, object value);
    }
}
