﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hot_Plate_Lib
{
    public class PLC_BaseUserControl: System.Windows.Controls.UserControl
    {
        
        public virtual string PLCReadAdress { get; set; }        
        public virtual string PLCWriteAdress { get; set; }

        //public virtual string PLCOffsetAdress { get; set; }
        //public virtual bool OffsetRead { get; set; }
        //public virtual float Offset { get; set; }


        public virtual object Value { get; set; }        
        
        public virtual StationName PLCStationName { get; set; } = StationName.AnaUnite;
    }
    public enum StationName
    {
        AnaUnite,
        Giris,
        Cikis

    }

}
